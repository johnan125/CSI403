
package csi403;

public class Student extends Person {
    private int[] grades; 
    public Student() { }
    public int[] getGrades() { return grades; }
    public void setGrades(int[] grades) { this.grades = grades; } 
} 
